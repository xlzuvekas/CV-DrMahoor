import os
import imageio

output_images = []  # list to store all output images
for file in sorted(os.listdir('.')):  # iterate over each file in current directory
    if file.startswith('output_') and file.endswith('.jpg'):  # if it's one of the output images
        output_images.append(imageio.imread(file))  # read and add to the list

# Create gif
imageio.mimsave('output.gif', output_images, fps=5)  # adjust fps for speed
