function img = morphTriangle(img1, img2, img, t1, t2, t, alpha)
    % Find bounding rectangle for each triangle
    r1 = boundingRect(t1);
    r2 = boundingRect(t2);
    r = boundingRect(t);

    % Offset points by left top corner of the respective rectangles
    t1Rect = bsxfun(@minus, t1, r1(1:2));
    t2Rect = bsxfun(@minus, t2, r2(1:2));
    tRect = bsxfun(@minus, t, r(1:2));

    % Get mask by filling triangle
    mask = poly2mask(tRect(:,1), tRect(:,2), r(4), r(3));

    % Warp triangles
    img1Rect = imcrop(img1, r1);
    img2Rect = imcrop(img2, r2);
    size = [r(4), r(3)];
    warpImage1 = applyAffineTransform(img1Rect, t1Rect, tRect, size);
    warpImage2 = applyAffineTransform(img2Rect, t2Rect, tRect, size);

    % Alpha blend rectangular patches
    imgRect = (1.0 - alpha) * warpImage1 + alpha * warpImage2;

    % Resize the mask to the size of the imgRect if they do not match
    if size(mask, 1) ~= size(imgRect, 1) || size(mask, 2) ~= size(imgRect, 2)
        mask = imresize(mask, [size(imgRect, 1), size(imgRect, 2)]);
    end

    % Copy triangular region of the rectangular patch to the output image
    img(r(2):(r(2)+r(4)), r(1):(r(1)+r(3)), :) = img(r(2):(r(2)+r(4)), r(1):(r(1)+r(3)), :) .* (1 - mask) + imgRect .* mask;
end
