filename1 = 'hillary_clinton.jpg';
filename2 = 'ted_cruz.jpg';
alpha = 0.5;

% Read images
img1 = imread(filename1);
img2 = imread(filename2);

% Convert Mat to float data type
img1 = im2double(img1);
img2 = im2double(img2);

% Read array of corresponding points
points1 = readPoints([filename1 '.txt']);
points2 = readPoints([filename2 '.txt']);
points = [];

% Compute weighted average point coordinates
for i = 1:size(points1,1)
    x = (1 - alpha) * points1(i,1) + alpha * points2(i,1);
    y = (1 - alpha) * points1(i,2) + alpha * points2(i,2);
    points = [points; x y];
end

% Allocate space for final output
imgMorph = zeros(size(img1), 'like', img1);

% Read triangles from tri.txt
fileID = fopen('tri.txt','r');
formatSpec = '%d %d %d';
sizeA = [3 Inf];
triangles = fscanf(fileID, formatSpec, sizeA);
triangles = triangles';
fclose(fileID);

for i = 1:size(triangles,1)
    x = triangles(i,1) + 1;
    y = triangles(i,2) + 1;
    z = triangles(i,3) + 1;

    t1 = [points1(x,:); points1(y,:); points1(z,:)];
    t2 = [points2(x,:); points2(y,:); points2(z,:)];
    t = [points(x,:); points(y,:); points(z,:)];

    % Morph one triangle at a time.
    imgMorph = morphTriangle(img1, img2, imgMorph, t1, t2, t, alpha);
end

% Display Result
imshow(imgMorph);

% Save the output image
outputFilename = ['output_' num2str(randi([1000000,9999999])) '.jpg'];
imwrite(imgMorph, outputFilename);
fprintf('Saved output image as: %s\n', outputFilename);
