function [dst] = applyAffineTransform(src, srcTri, dstTri, size)

    tform = fitgeotrans(srcTri, dstTri, 'Affine');
    dst = imwarp(src, tform, 'OutputView', imref2d(size));
end