function points = readPoints(path)
    points = [];
    fileID = fopen(path,'r');
    formatSpec = '%f %f';
    sizeA = [2 Inf];
    points = fscanf(fileID, formatSpec, sizeA);
    points = points';
    fclose(fileID);
end