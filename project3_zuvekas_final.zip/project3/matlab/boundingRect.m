
function rect = boundingRect(points)
    minX = min(points(:,1));
    minY = min(points(:,2));
    maxX = max(points(:,1));
    maxY = max(points(:,2));
    rect = [minX minY maxX-minX maxY-minY];
end
